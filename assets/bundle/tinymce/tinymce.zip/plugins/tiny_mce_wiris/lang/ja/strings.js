var strings = new Array();
strings['cancel'] = 'キャンセル';
strings['accept'] = 'OK';
strings['manual'] = 'マニュアル';
strings['latex'] = 'LaTeX';