var strings = new Array();
strings['cancel'] = 'Άκυρο';
strings['accept'] = 'ΟΚ';
strings['manual'] = 'Χειροκίνητα';
strings['latex'] = 'LaTeX';