var strings = new Array();
strings['cancel'] = 'Peruuta';
strings['accept'] = 'OK';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';